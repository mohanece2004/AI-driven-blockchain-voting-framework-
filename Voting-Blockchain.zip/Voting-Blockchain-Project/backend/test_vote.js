const testUserId = 'test_' + Date.now();
const testCandidateId = 1;

console.log('Testing vote with:', { userId: testUserId, candidateId: testCandidateId });

fetch('http://localhost:5000/api/vote', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ userId: testUserId, candidateId: testCandidateId })
})
  .then(async (res) => {
    console.log('Status:', res.status);
    const data = await res.json();
    console.log('Response:', JSON.stringify(data, null, 2));
  })
  .catch((err) => {
    console.error('Fetch error:', err.message);
  });
