require('dotenv').config();  // Load environment variables from .env
const express = require('express');
const sqlite3 = require('sqlite3').verbose();  // SQLite for the database
const twilio = require('twilio');  // Twilio for SMS
const crypto = require('crypto');  // To generate OTP
const router = express.Router();

// Twilio Configuration
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = new twilio(accountSid, authToken);
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;  // Your Twilio phone number

// Initialize the database connection
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Database opened successfully.');
  }
});

// Create Users Table
const createTableQuery = `
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone_number TEXT UNIQUE NOT NULL,
    otp TEXT,
    otp_expiry TIMESTAMP
  )
`;

db.run(createTableQuery, (err) => {
  if (err) {
    console.error('Error creating users table:', err);
  } else {
    console.log('Users table is ready.');
  }
});

// Ensure OTP columns exist (for older DBs that may lack them)
function ensureUserColumns() {
  db.all("PRAGMA table_info(users)", (err, rows) => {
    if (err) {
      console.error('Error checking users table schema:', err);
      return;
    }

    const columnNames = rows.map(r => r.name);

    if (!columnNames.includes('otp')) {
      db.run("ALTER TABLE users ADD COLUMN otp TEXT", (alterErr) => {
        if (alterErr) console.error('Error adding otp column:', alterErr);
        else console.log('Added otp column to users table.');
      });
    }

    if (!columnNames.includes('otp_expiry')) {
      db.run("ALTER TABLE users ADD COLUMN otp_expiry TIMESTAMP", (alterErr) => {
        if (alterErr) console.error('Error adding otp_expiry column:', alterErr);
        else console.log('Added otp_expiry column to users table.');
      });
    }
  });
}

// Run the schema check after ensuring the table exists
ensureUserColumns();

// Create separate table for OTPs to avoid inserting incomplete user records
const createOtpsTable = `
  CREATE TABLE IF NOT EXISTS otps (
    phone_number TEXT UNIQUE NOT NULL,
    otp TEXT,
    otp_expiry TIMESTAMP
  )
`;

db.run(createOtpsTable, (err) => {
  if (err) console.error('Error creating otps table:', err);
  else console.log('Otps table is ready.');
});

// Generate OTP
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();  // Generates a 6-digit OTP as a string
}

// Send OTP via SMS using Twilio
function sendSMS(phoneNumber, otp) {
  return client.messages.create({
    body: `Your OTP for login is: ${otp}`,
    to: phoneNumber,
    from: twilioPhoneNumber,  // Your Twilio phone number
  });
}

// Add or Update OTP in the Database
function addOrUpdateOTP(phoneNumber, otp, otpExpiry) {
  return new Promise((resolve, reject) => {
    // Use the otps table so we don't need to insert incomplete users
    db.get('SELECT * FROM otps WHERE phone_number = ?', [phoneNumber], (err, row) => {
      if (err) return reject(err);

      if (!row) {
        const query = 'INSERT INTO otps (phone_number, otp, otp_expiry) VALUES (?, ?, ?)';
        db.run(query, [phoneNumber, otp, otpExpiry], function (err) {
          if (err) return reject(err);
          resolve('OTP added to otps table');
        });
      } else {
        const updateQuery = 'UPDATE otps SET otp = ?, otp_expiry = ? WHERE phone_number = ?';
        db.run(updateQuery, [otp, otpExpiry, phoneNumber], function (err) {
          if (err) return reject(err);
          resolve('OTP updated in otps table');
        });
      }
    });
  });
}

// Login Route: Send OTP to the provided phone number
router.post('/login', async (req, res) => {
  const { phone_number } = req.body;

  // Validate phone number input
  if (!phone_number) {
    return res.status(400).json({ error: 'Phone number is required' });
  }

  // Generate OTP for login
  const otp = generateOTP();
  const otpExpiry = new Date(Date.now() + 5 * 60 * 1000); // OTP expires in 5 minutes

  try {
    // Add or update OTP in the database
    await addOrUpdateOTP(phone_number, otp, otpExpiry);
    console.log('OTP stored in database:', { phone_number, otp, otpExpiry });

    // Send OTP via SMS
    await sendSMS(phone_number, otp);
    console.log('OTP sent to:', phone_number);

    return res.status(200).json({
      message: 'OTP sent successfully to your phone. Please check your messages.',
      phoneNumber: phone_number,
    });
  } catch (error) {
    console.error('Error during login:', error);
    return res.status(500).json({ error: 'Error during login process' });
  }
});

// OTP Verification Route: Verify the submitted OTP
router.post('/verify-otp', (req, res) => {
  const { phone_number, otp } = req.body;

  if (!phone_number || !otp) {
    return res.status(400).json({ error: 'Phone number and OTP are required' });
  }

  // Verify OTP against the otps table
  db.get('SELECT * FROM otps WHERE phone_number = ?', [phone_number], (err, otpRow) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    if (!otpRow) {
      return res.status(400).json({ error: 'No OTP found for this phone number' });
    }

    console.log('Stored OTP:', otpRow.otp);
    console.log('Submitted OTP:', otp);

    if (otpRow.otp !== otp) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    const currentTime = new Date();
    const otpExpiryTime = new Date(otpRow.otp_expiry);
    if (currentTime > otpExpiryTime) {
      return res.status(400).json({ error: 'OTP has expired' });
    }

    // Optionally look up the user id in users table
    db.get('SELECT id FROM users WHERE phone_number = ?', [phone_number], (uErr, userRow) => {
      if (uErr) {
        console.error('Database error fetching user:', uErr);
        return res.status(500).json({ error: 'Database error' });
      }

      const response = {
        message: 'OTP verified successfully. Proceeding to home page.',
      };

      if (userRow && userRow.id) response.userId = userRow.id;
      else response.phoneNumber = phone_number;

      return res.status(200).json(response);
    });
  });
});

module.exports = router;