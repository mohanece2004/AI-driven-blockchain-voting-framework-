const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const router = express.Router();

// Initialize the database connection
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Database opened successfully.');

    // Create 'candidates' table with 'imageUrl' column
    db.run(`
      CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        party TEXT NOT NULL,
        votes INTEGER DEFAULT 0,
        imageUrl TEXT NOT NULL
      )
    `, (err) => {
      if (err) {
        console.error('Error creating candidates table:', err);
      } else {
        console.log("'candidates' table is ready.");

        // Insert default candidates if table is empty
        db.get('SELECT COUNT(*) AS count FROM candidates', (err, row) => {
          if (err) {
            console.error('Error checking candidates count:', err);
          } else if (row.count === 0) {
            const defaultCandidates = [
              { 
                name: 'Narendra Modi', 
                party: 'Bharatiya Janata Party (BJP)',
                imageUrl: '../image/c1.jpg' 
              },
              { 
                name: 'Rahul Gandhi', 
                party: 'Indian National Congress (INC)',
                imageUrl: '../image/c2.jpg' 
              },
              { 
                name: 'Arvind Kejriwal', 
                party: 'Aam Aadmi Party (AAP)',
                imageUrl: '../image/c3.jpg' 
              },
              { 
                name: 'Mamata Banerjee', 
                party: 'All India Trinamool Congress (TMC)',
                imageUrl: '../image/c4.jpg' 
              }
            ];

            const insertQuery = 'INSERT INTO candidates (name, party, votes, imageUrl) VALUES (?, ?, 0, ?)';

            defaultCandidates.forEach(candidate => {
              db.run(insertQuery, [candidate.name, candidate.party, candidate.imageUrl], (err) => {
                if (err) {
                  console.error(`Error inserting candidate '${candidate.name}':`, err);
                } else {
                  console.log(`Candidate '${candidate.name}' added.`);
                }
              });
            });
          }
        });
      }
    });

    // Create 'votes' table if it doesn't exist
    db.run(`
      CREATE TABLE IF NOT EXISTS votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        candidate_id INTEGER NOT NULL,
        UNIQUE(user_id)
      )
    `, (err) => {
      if (err) {
        console.error('Error creating votes table:', err);
      } else {
        console.log("'votes' table is ready.");
      }
    });
  }
});

// Vote Route: User votes for a candidate
router.post('/vote', (req, res) => {
  const { userId, candidateId } = req.body;

  console.log('Vote request:', { userId, candidateId, userIdType: typeof userId });

  if (!userId || !candidateId) {
    return res.status(400).json({ error: 'User ID and Candidate ID are required' });
  }

  const checkVoteQuery = 'SELECT * FROM votes WHERE user_id = ?';
  // Validate candidate exists before inserting vote
  db.get('SELECT id FROM candidates WHERE id = ?', [candidateId], (cErr, cRow) => {
    if (cErr) {
      console.error('Database error checking candidate:', cErr);
      return res.status(500).json({ error: 'Database error', details: cErr.message });
    }

    if (!cRow) {
      return res.status(400).json({ error: 'Invalid Candidate ID' });
    }

    db.get(checkVoteQuery, [userId], (err, row) => {
      if (err) {
        console.error('Database error:', err);
        return res.status(500).json({ error: 'Database error', details: err.message });
      }

      if (row) {
        return res.status(400).json({ error: 'User has already voted.' });
      }

      const insertVoteQuery = 'INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)';
      db.run(insertVoteQuery, [userId, candidateId], function (err) {
        if (err) {
          console.error('Error inserting vote:', err);
          // Map common constraint to clearer message
          if (err.code === 'SQLITE_CONSTRAINT' && /UNIQUE/.test(err.message)) {
            return res.status(400).json({ error: 'User has already voted.' });
          }
          return res.status(500).json({ error: 'Database error', details: err.message });
        }

        const updateCandidateQuery = 'UPDATE candidates SET votes = votes + 1 WHERE id = ?';
        db.run(updateCandidateQuery, [candidateId], function (err) {
          if (err) {
            console.error('Error updating candidate votes:', err);
            return res.status(500).json({ error: 'Database error', details: err.message });
          }

          res.status(200).json({ message: 'Vote recorded successfully.' });
        });
      });
    });
  });
});

// Get all candidates
router.get('/candidates', (req, res) => {
  const query = 'SELECT * FROM candidates';
  db.all(query, [], (err, rows) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.status(200).json(rows);
  });
});

module.exports = router;
