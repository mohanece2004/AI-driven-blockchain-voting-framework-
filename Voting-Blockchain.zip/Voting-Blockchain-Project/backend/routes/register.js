require('dotenv').config();  // Load environment variables from .env
const express = require('express');
const sqlite3 = require('sqlite3').verbose();  // SQLite for the database
const router = express.Router();

// Initialize the database connection
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Database opened successfully.');
  }
});

// Create Users Table
const createTableQuery = `
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone_number TEXT UNIQUE NOT NULL,
    vote_id TEXT NOT NULL,
    address TEXT NOT NULL,
    state TEXT NOT NULL,
    dob TEXT NOT NULL
  )
`;

db.run(createTableQuery, (err) => {
  if (err) {
    console.error('Error creating users table:', err);
  } else {
    console.log('Users table is ready.');
  }
});

// Validate phone number (Indian number format)
function validatePhoneNumber(phoneNumber) {
  const phoneRegex = /^\+91[789]\d{9}$/;  // Indian phone number starting with +91 and followed by 10 digits
  return phoneRegex.test(phoneNumber);
}

// Check if phone number is already registered
function isPhoneNumberRegistered(phoneNumber) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM users WHERE phone_number = ?', [phoneNumber], (err, row) => {
      if (err) {
        return reject(err);
      }
      resolve(!!row);  // Returns true if the phone number is already registered
    });
  });
}

// Insert user into the database
function insertUser(userDetails) {
  return new Promise((resolve, reject) => {
    const { name, phone_number, vote_id, address, state, dob } = userDetails;
    const query = `
      INSERT INTO users (name, phone_number, vote_id, address, state, dob)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    db.run(query, [name, phone_number, vote_id, address, state, dob], function (err) {
      if (err) {
        return reject(err);
      }
      resolve(this.lastID);  // Return the ID of the inserted user
    });
  });
}

// Register Route: User submits registration details
router.post('/register', async (req, res) => {
  const { name, phone_number, vote_id, address, state, dob } = req.body;

  // Validate input fields
  if (!name || !phone_number || !vote_id || !address || !state || !dob) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  // Validate phone number format
  if (!validatePhoneNumber(phone_number)) {
    return res.status(400).json({ error: 'Invalid phone number format. Use +91 followed by 10 digits.' });
  }

  // Check if the phone number is already registered
  try {
    const isRegistered = await isPhoneNumberRegistered(phone_number);
    if (isRegistered) {
      return res.status(400).json({ error: 'Phone number is already registered' });
    }
  } catch (err) {
    console.error('Database error:', err);
    return res.status(500).json({ error: 'Database error' });
  }

  // Insert the user into the database
  try {
    const userId = await insertUser({
      name,
      phone_number,
      vote_id,
      address,
      state,
      dob,
    });
    console.log('User registered with ID:', userId);

    return res.status(200).json({
      message: 'User registered successfully.',
      userId,  // Return the user ID of the inserted record
    });
  } catch (err) {
    console.error('Error during registration:', err);
    return res.status(500).json({ error: 'Error during registration process' });
  }
  
});

module.exports = router;