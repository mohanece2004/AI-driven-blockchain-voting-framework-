const dgram = require('dgram');
const express = require('express');
const router = express.Router();

// UDP configuration - ADJUST THESE TO MATCH YOUR LCD DEVICE
const UDP_HOST = '255.255.255.255';  // Change to your LCD device IP address
const UDP_PORT = 4210;              // Change to your LCD device UDP port

console.log(`UDP Route: Configured to send to ${UDP_HOST}:${UDP_PORT}`);

// Route to send UDP message to LCD display
router.post('/send-udp', (req, res) => {
  const { message, status } = req.body;

  console.log('UDP send request:', { message, status, UDP_HOST, UDP_PORT });

  if (!message && !status) {
    return res.status(400).json({ error: 'Message or status is required' });
  }

  try {
    const client = dgram.createSocket('udp4');
    
    // Enable broadcast mode for broadcast addresses like 255.255.255.255
    client.bind(() => {
      client.setBroadcast(true);
    });
    
    const msgBuffer = Buffer.from(status || message);

    console.log(`Sending UDP: "${status || message}" to ${UDP_HOST}:${UDP_PORT}`);

    client.send(msgBuffer, 0, msgBuffer.length, UDP_PORT, UDP_HOST, (err) => {
      if (err) {
        console.error('UDP send error:', err.message);
        client.close();
        return res.status(500).json({ error: 'Failed to send UDP message', details: err.message });
      }

      console.log(`✓ UDP sent successfully: "${status || message}"`);
      client.close();
      res.status(200).json({ message: 'UDP message sent successfully', data: { status, message } });
    });

  } catch (err) {
    console.error('UDP error:', err);
    res.status(500).json({ error: 'UDP error', details: err.message });
  }
});

module.exports = router;
