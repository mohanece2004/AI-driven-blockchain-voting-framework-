require('dotenv').config();
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const router = express.Router();

// Initialize SQLite database connection
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Connected to the voting database.');
  }
});

// Route to check Vote ID and DOB and return user details
router.post('/voteidchecker', (req, res) => {
  const { vote_id, dob } = req.body;

  if (!vote_id || !dob) {
    console.warn('voteidchecker: missing fields', { vote_id, dob });
    return res.status(400).json({ error: 'Vote ID and DOB are required.' });
  }

  // First lookup by vote_id (exact match), then compare DOB in JS with normalization
  const query = 'SELECT id, name, vote_id, dob, phone_number FROM users WHERE vote_id = ?';
  console.log('voteidchecker: lookup', { vote_id, dob });
  db.get(query, [vote_id.trim()], (err, user) => {
    if (err) {
      console.error('Database error:', err.message);
      return res.status(500).json({ error: 'Database error.' });
    }

    if (!user) {
      console.info('voteidchecker: vote_id not found', vote_id);
      return res.status(404).json({ error: 'Vote ID not found.' });
    }

    // Normalize DOBs to compare (attempt ISO yyyy-mm-dd)
    function normalizeDob(d) {
      if (!d) return '';
      // If already YYYY-MM-DD, keep
      const isoMatch = d.match(/^\d{4}-\d{2}-\d{2}$/);
      if (isoMatch) return d;

      // Try Date parse and convert to YYYY-MM-DD
      const parsed = new Date(d);
      if (!isNaN(parsed)) {
        return parsed.toISOString().slice(0, 10);
      }

      // Fallback: remove non-digits and try to reconstruct
      const digits = d.replace(/\D/g, '');
      if (digits.length === 8) {
        // assume DDMMYYYY or YYYYMMDD - try both
        const d1 = digits.slice(4) + '-' + digits.slice(2,4) + '-' + digits.slice(0,2); // YYYY-MM-DD if input was YYYYMMDD
        const d2 = digits.slice(4) + '-' + digits.slice(2,4) + '-' + digits.slice(0,2); // fallthrough
        return d1;
      }

      return d;
    }

    const providedDob = normalizeDob(dob.toString().trim());
    const storedDob = normalizeDob((user.dob || '').toString().trim());

    if (providedDob === storedDob) {
      return res.status(200).json({ message: 'Voter details retrieved successfully.', user });
    }

    console.info('voteidchecker: dob mismatch', { vote_id, providedDob, storedDob });
    // If DOB doesn't match after normalization, return explicit message
    return res.status(404).json({ error: 'Vote ID found but DOB does not match.' });
  });
});

module.exports = router;
