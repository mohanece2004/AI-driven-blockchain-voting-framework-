const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) { console.error('open error', err); process.exit(1); }

  const userId = 1;
  const candidateId = 1;

  db.get('SELECT * FROM votes WHERE user_id = ?', [userId], (e, row) => {
    if (e) { console.error('check vote error', e); db.close(); return; }
    if (row) { console.log('User already voted:', row); db.close(); return; }

    db.get('SELECT * FROM candidates WHERE id = ?', [candidateId], (ce, cRow) => {
      if (ce) { console.error('candidate check error', ce); db.close(); return; }
      if (!cRow) { console.log('Candidate not found'); db.close(); return; }

      db.run('INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)', [userId, candidateId], function (err) {
        if (err) { console.error('insert vote error', err); db.close(); return; }
        const insertedId = this.lastID;
        console.log('Inserted vote id', insertedId);

        db.run('UPDATE candidates SET votes = votes + 1 WHERE id = ?', [candidateId], function (uErr) {
          if (uErr) {
            console.error('update candidate error', uErr);
            db.run('DELETE FROM votes WHERE id = ?', [insertedId], () => db.close());
            return;
          }

          console.log('Candidate votes incremented');

          // rollback cleanup
          db.run('DELETE FROM votes WHERE id = ?', [insertedId], function (dErr) {
            if (dErr) console.error('cleanup delete error', dErr);
            db.run('UPDATE candidates SET votes = votes - 1 WHERE id = ?', [candidateId], function (udErr) {
              if (udErr) console.error('cleanup dec error', udErr);
              console.log('Cleanup done');
              db.close();
            });
          });
        });
      });
    });
  });
});
