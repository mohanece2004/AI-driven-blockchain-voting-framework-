/***********************
 * ENV & DEPENDENCIES
 ***********************/
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const dgram = require('dgram');

/***********************
 * EXPRESS SETUP
 ***********************/
const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Serve candidate images
app.use('/image', express.static(path.join(__dirname, 'image')));
app.use(
  '/image',
  express.static(path.join(__dirname, '..', 'frontend', 'public', 'image'))
);

/***********************
 * ROUTES
 ***********************/
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');
const voteRoute = require('./routes/vote');
const voteIdCheckerRoute = require('./routes/voteidchecker');
const udpRoute = require('./routes/udp');

app.use('/api', registerRoute);
app.use('/api', loginRoute);
app.use('/api', voteRoute);
app.use('/api', voteIdCheckerRoute);
app.use('/api', udpRoute);

// Health check
app.get('/', (req, res) => {
  res.send('Server is running');
});

/***********************
 * START EXPRESS SERVER
 ***********************/
app.listen(port, () => {
  console.log(`✅ Express Server running on port ${port}`);
});

/***********************
 * UDP BROADCAST SETUP
 ***********************/
const UDP_PORT = 4210;
const BROADCAST_IP = '255.255.255.255';

const udpSocket = dgram.createSocket('udp4');

udpSocket.bind(() => {
  udpSocket.setBroadcast(true);
  console.log('📡 UDP Broadcast Sender Ready');
});

/***********************
 * TERMINAL INPUT → UDP
 ***********************/
process.stdin.setEncoding('utf8');

process.stdin.on('data', (data) => {
  const message = data.trim();
  if (!message) return;

  const buffer = Buffer.from(message);

  udpSocket.send(buffer, UDP_PORT, BROADCAST_IP, (err) => {
    if (err) {
      console.error('❌ UDP send error:', err);
    } else {
      console.log(`📢 Broadcasted: ${message}`);
    }
  });
});
