const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./voting.db', (err) => {
  if (err) {
    console.error('DB open error:', err);
    process.exit(1);
  }

  console.log('CANDIDATES:');
  db.all('SELECT id, name, votes FROM candidates', (e, rows) => {
    if (e) console.error(e);
    else console.log(JSON.stringify(rows, null, 2));

    console.log('\nVOTES:');
    db.all('SELECT * FROM votes', (e2, rows2) => {
      if (e2) console.error(e2);
      else console.log(JSON.stringify(rows2, null, 2));
      db.close();
    });
  });
});
